import React from 'react';

let status = false;

const isLoggedIn = props => {
    status = {props.loginstatus};
    return status;
};

export default isLoggedIn;