import React, { useState, useEffect } from 'react';
import Axios from 'axios';
import SanfStad from '../Images/sanford_stadium.jpg';
import '../css/Locations.css'

let routes;

const Locations = props => {

    const [ newTitle, setNewTitle ] = useState("");
    const [ newPictureURL, setNewPictureURL ] = useState("");
    const [ newDescription, setNewDescription ] = useState("");
    const [ newAddress, setNewAddress ] = useState("");
    const [ locationList, setLocationList ] = useState([]);
    const [ editTitle, setEditTitle ] = useState("");

    // Add new location
    const addNewLocation = () => {
        Axios.post('http://localhost:3001/addloc', {
            title: newTitle, 
            pictureURL: newPictureURL,
            description: newDescription,
            address: newAddress
        });
    };

    // Edit location
    const editLocation = (id) => {
        Axios.put('http://localhost:3001/editloc', {
            id: id,
            edittitle: editTitle
        });
    };

    useEffect(() => {
        Axios.get("http://localhost:3001/loclist").then((response) => {
            console.log(response);
            setLocationList(response.data);
        });
    }, []);

    if (props.isLoggedIn) {
        routes = (
            <div className='loc-creater'>
                <h2>Add your Location</h2>
                <form>
                    <label for="title"><b>Title</b></label>
                    <br></br>
                    <input type="text" placeholder="Enter Title" name="title" onChange={ (event) => {setNewTitle(event.target.value)} } required></input>
                    <br></br>

                    <label for="picture"><b>Picture</b></label>
                    <br></br>
                    <input type="text" placeholder="Enter the URL" name="picture" onChange={ (event) => {setNewPictureURL(event.target.value)} } required></input>
                    <br></br>

                    <label for="description"><b>Description</b></label>
                    <br></br>
                    <input type="text" placeholder="Enter Description" name="description" onChange={ (event) => {setNewDescription(event.target.value)} } required></input>
                    <br></br>

                    <label for="address"><b>Address</b></label>
                    <br></br>
                    <input type="text" placeholder="Enter Address" name="address" onChange={ (event) => {setNewAddress(event.target.value)} } required></input>
                    <br></br>

                    <button type="submit" name="loc-submit" onClick={ addNewLocation }><b>Submit</b></button>
                </form>

                <div className='loc-container'>
                    { locationList.map((val, key) => {
                        return (
                            <div>
                                <img src={SanfStad} alt='sanford-stadium'></img>
                                <h2>{val.title}</h2>
                                <div>
                                    <p>{val.description}</p>
                                    <p><b>Address: </b>{val.address}</p>
                                </div>
                                <input type='text' onChange={ (event) => {setEditTitle(event.target.value)} }></input>
                                <div className='btn-modify-item'>
                                    <button onClick={() => editLocation(val._id)}><b>Edit</b></button>
                                    <button><b>Delete</b></button>
                                </div>
                            </div>
                        );
                    })};
                </div>
            </div>           
        );
    } else {
        routes = (
            <div className='loc-container'>
                { locationList.map((val, key) => {
                    return (
                        <div>
                            <img src={SanfStad} alt='sanford-stadium'></img>
                            <h2>{val.title}</h2>
                            <div>
                                <p>{val.description}</p>
                                <p><b>Address: </b>{val.address}</p>
                            </div>
                        </div>
                    );
                })};
            </div>
        );
    }

    return(routes);
};

export default Locations;