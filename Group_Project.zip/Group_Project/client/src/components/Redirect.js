import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

const Redirect = () => {
  const [count, setCount] = useState(5);
  const navigate = useNavigate();
  
  useEffect(() => {
    const interval = setInterval(() => {
      // update the state after 1000ms
      setCount((currentCount) => currentCount - 1);
    }, 1000);
    // when count is 0, navigate
    count === 0 && navigate("/");
    // clean up the interval
    return () => clearInterval(interval);
  }, [count, navigate]);
};

export default Redirect;