import React from 'react';
import '../css/Logout.css';

const Logout = props => (
    <div>
        <h2 className='logout-msg'>You have successfully logged out!</h2>
    </div>
);

export default Logout;