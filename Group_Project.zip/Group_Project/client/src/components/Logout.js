import React from 'react';
import '../css/Logout.css';

const Logout = props => (
    <h2 className='logout-msg'>You have successfully logged out!</h2>
);

export default Logout;