import React from 'react';
import '../css/NavLinks.css';

let routes;

const NavLinks = props => {

    if (props.isLoggedIn) {
        routes = (
            <ul className='nav-links'>
                <li>
                    <a href="/">Home</a>
                </li>
                <li>
                    <a href="/about">About</a>
                </li>
                <li>
                    <a href="/more_info">Information</a>
                </li>
                <li>
                    <a href="/locations">Locations</a>
                </li>
                <li>
                    <a href="/logout" id='logout' onClick={props.onclick}>Logout</a>
                </li>
            </ul>
        );
    } else {
        routes = (
            <ul className='nav-links'>
                <li>
                    <a href="/">Home</a>
                </li>
                <li>
                    <a href="/about">About</a>
                </li>
                <li>
                    <a href="/more_info">Information</a>
                </li>
                <li>
                    <a href="/locations">Locations</a>
                </li>
                <li>
                    <a href="/login">Login</a>
                </li>
            </ul>
        );
    }

    return routes;
};

export default NavLinks;