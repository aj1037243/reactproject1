import React, { useState } from 'react';
import Axios from 'axios';
import '../css/Login.css';

const Login = props => {

    const [ email, setEmail ] = useState("");
    const [ password, setPassword ] = useState("");

    const confirmUserInfo = () => {
        Axios.post("http://localhost:3001/login", { 
          email: email, 
          password: password
        });
    };
    
    return(
        <div className='loginbox'>
            <h2>Login</h2>
            <hr></hr>
            <form>
                <div className='username-box'>
                    <label for="username"><b>Email</b></label>
                    <br></br>
                    <input type="text" placeholder="Enter Username" name="uname" onChange={ (event) => {setEmail(event.target.value)} } required></input>
                </div>
                <div className='password-box'>
                    <label for="password"><b>Password</b></label>
                    <br></br>
                    <input type="password" placeholder="Enter Password" name="psw" onChange={ (event) => {setPassword(event.target.value)} } required></input>
                </div>
                <button type="submit" onClick={ confirmUserInfo }><b>Login</b></button>

                <div className='signup-container'>
                    <p>First-time user? <a href='/signup'>Create an account.</a></p>
                </div>
            </form>
        </div>
    );
};

export default Login;