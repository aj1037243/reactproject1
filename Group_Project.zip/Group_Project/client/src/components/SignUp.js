import React, { useState } from 'react';
import Axios from 'axios';
import '../css/SignUp.css'

const SignUp = props => {
    
    const [ newEmail, setEmail ] = useState("");
    const [ newPassword, setPassword ] = useState("");
    const [ newPasswordConf, setPasswordConf] = useState("");

    const addUser = () => {
        Axios.post("http://localhost:3001/signup", { 
        email: newEmail, 
        password: newPassword,
        passwordConf: newPasswordConf
        });
    };

    return (
        <div className='signup-box'>
            <h2>Sign Up</h2>
            <hr></hr>
            <form id='reg-form'>
                <div className='username-signup'>
                    <label for="username"><b>Enter your Email</b></label>
                    <br></br>
                    <input type="text" placeholder="Enter Email" name="usn-signup" onChange={ (event) => {setEmail(event.target.value)} } required></input>
                </div>
                <div className='password-signup'>
                    <label for="password"><b>Choose your Password</b></label>
                    <br></br>
                    <input type="password" placeholder="Enter Password" name="psw-signup" onChange={ (event) => {setPassword(event.target.value)} } required></input>
                </div>
                <div className='password-signup'>
                    <label for="password"><b>Re-enter your Password</b></label>
                    <br></br>
                    <input type="password" placeholder="Re-enter Password" name="psw-signup" onChange={ (event) => {setPasswordConf(event.target.value)} } required></input>
                </div>
                <button type="submit" name="btn-signup" onClick={ addUser }><b>Sign Up!</b></button>
            </form>
        </div>
    );
};

export default SignUp;