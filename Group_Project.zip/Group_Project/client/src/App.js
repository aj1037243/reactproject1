import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import Axios from 'axios';
import MainNavigation from './components/MainNavigation';
import Main from './components/Main';
import Home from './components/Home';
import About from './components/About';
import MoreInformation from './components/MoreInformation';
import Locations from './components/Locations';
import Logout from './components/Logout';
import Redirect from './components/Redirect';
import Footer from './components/Footer';
import './css/App.css'

let routes;

const App = () => {

    const [ isLoggedIn, setIsLoggedIn ] = useState(false);
    const [ newEmail, setNewEmail ] = useState("");
    const [ newPassword, setNewPassword ] = useState("");
    const [ newPasswordConf, setNewPasswordConf] = useState("");
    const [ eneterdEmail, setEnteredEmail ] = useState("");
    const [ enteredPassword, setEnteredPassword ] = useState("");

    // Adds User to the server
    const addUser = () => {
        Axios.post("http://localhost:3001/signup", { 
        email: newEmail, 
        password: newPassword,
        passwordConf: newPasswordConf
        });
    };

    // Confirm user info
    const confirmUserInfo = () => {
        Axios.post("http://localhost:3001/login", { 
          email: eneterdEmail, 
          password: enteredPassword
        });
    };

    // Authenticate User
    useEffect(() => {
        Axios.get("http://localhost:3001/auth").then((response) => {
            setIsLoggedIn(response.data);
        });
    }, []);

    // Logout User
    const LogoutUser = () => {
        Axios.post("http://localhost:3001/logout", {});
    };

    // Navigate to Home page
    const returnHome = () => {
        return <Navigate to='/' />;
    };

    if (isLoggedIn) {
        routes = (
            <Routes>
                <Route path='/' element={<Main />}>
                    <Route index element={<Home />} />
                </Route>
                <Route path="/about" element={<About />} />
                <Route path="/more_info" element={<MoreInformation />} />
                <Route path="/locations" element={<Locations isLoggedIn={isLoggedIn} />} />
                <Route path="/login" element={returnHome()} />
            </Routes>
        );
    } else {
        routes = (
            <Routes>
                <Route path='/' element={<Main />}>
                    <Route index element={<Home />} />
                </Route>
                <Route path="/about" element={<About />} />
                <Route path="/more_info" element={<MoreInformation />} />
                <Route path="/locations" element={<Locations isLoggedIn={isLoggedIn} />} />
                <Route path="/logout" element={<><Logout /><Redirect /></>} />
                <Route path="/login" element={
                    <div className='loginbox'>
                        <h2>Login</h2>
                        <hr></hr>
                        <form>
                            <div className='username-box'>
                                <label for="username"><b>Email</b></label>
                                <br></br>
                                <input type="text" placeholder="Enter Username" name="uname" onChange={ (event) => {setEnteredEmail(event.target.value)} } required></input>
                            </div>
                            <div className='password-box'>
                                <label for="password"><b>Password</b></label>
                                <br></br>
                                <input type="password" placeholder="Enter Password" name="psw" onChange={ (event) => {setEnteredPassword(event.target.value)} } required></input>
                            </div>
                            <button type="submit" onClick={ (event) => { confirmUserInfo(); } }><b>Login</b></button>       
                            <div className='signup-container'>
                                <p>First-time user? <a href='/signup'>Create an account.</a></p>
                            </div>
                        </form>
                    </div>
                } />
                <Route path="/signup" element={
                    <div className='signup-box'>
                        <h2>Sign Up</h2>
                        <hr></hr>
                        <form id='reg-form'>
                            <div className='username-signup'>
                                <label for="username"><b>Enter your Email</b></label>
                                <br></br>
                                <input type="text" placeholder="Enter Email" name="usn-signup" onChange={ (event) => {setNewEmail(event.target.value)} } required></input>
                            </div>
                            <div className='password-signup'>
                                <label for="password"><b>Choose your Password</b></label>
                                <br></br>
                                <input type="password" placeholder="Enter Password" name="psw-signup" onChange={ (event) => {setNewPassword(event.target.value)} } required></input>
                            </div>
                            <div className='password-signup'>
                                <label for="password"><b>Re-enter your Password</b></label>
                                <br></br>
                                <input type="password" placeholder="Re-enter Password" name="psw-signup" onChange={ (event) => {setNewPasswordConf(event.target.value)} } required></input>
                            </div>
                            <button type="submit" name="btn-signup" onClick={ addUser }><b>Sign Up!</b></button>
                        </form>
                    </div>
                } />
            </Routes>
        );
    }

    return (
        <React.Fragment>
            <MainNavigation isLoggedIn={isLoggedIn} onclick={ LogoutUser } />
            <BrowserRouter>{routes}</BrowserRouter>
            <Footer isLoggedIn={isLoggedIn} />
        </React.Fragment>
    );
};

export default App;