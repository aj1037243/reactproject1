const express = require('express');
const app = express(); // initialize express server
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

const { User } = require('./models/User');
const { Location } = require('./models/Location');


app.use(express.json());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors());

// Connect to MongoDB
const dbURL = "mongodb+srv://newuser4300:123qwe@csci4300.tb9atny.mongodb.net/CSCI4300"
mongoose.connect(dbURL, {
    useNewUrlParser: true, useUnifiedTopology: true
})
.then(() => console.log("MongoDB Connected!"))
.catch((err) => console.log(err));

// Define variables
let isLoggedIn;

// User Signup
app.post('/signup', async (req, res) => {

    const newEmail = req.body.email.trim();
    const newPassword = req.body.password;
    const newPasswordConf = req.body.passwordConf;

    let existingEmail = await User.find({ email: newEmail }).select('email');

    if(existingEmail[0] == undefined) {
        if (newPassword.length < 6) {
            console.log("Passwords must be 6 characters or longer.");
        } else if (newPassword != newPasswordConf) {
            console.log("Password does not match.");
        } else {
            const newuser = new User({ 
                email: newEmail, 
                password: newPassword
            });
    
            await newuser.save();
        };
    } else {
        console.log("The email already exists.");       
    };
});

// User Login
app.post('/login', async (req, res) => {

    const enteredEmail = req.body.email.trim();
    const enteredPassword = req.body.password;

    let existingUser = await User.find({ email: enteredEmail, password: enteredPassword });

    if (existingUser[0] == undefined) {
        console.log("Invalid email or password.");
        isLoggedIn = false;
    } else {
        console.log("Login success.");
        isLoggedIn = true;
    };

    //Authenticate User
    app.get('/auth', async (req, res) => {
        res.send(isLoggedIn);
    });
});

//Logout
app.post('/logout', async (req, res) => {
    isLoggedIn = false;
    
    app.get('/auth', async (req, res) => {
        res.send(isLoggedIn);
    });
});

// Add Location
app.post('/addloc', async (req, res) => {

    const newTitle = req.body.title;
    const newPictureURL = req.body.pictureURL;
    const newDescription = req.body.description;
    const newAddress = req.body.address;
    
    const newLocation = new Location({ 
        title: newTitle, 
        pictureURL: newPictureURL,
        description: newDescription,
        address: newAddress
    });

    await newLocation.save();
});

// Send list of locations
app.get('/loclist', async (req, res) => {
    Location.find({}, (err, result) => {
        if (err) {
            res.send(err);
        }

        res.send(result);
    });
});

// PORT: 3001
app.listen(3001, () => {
    console.log('Server running on port 3001.');
});