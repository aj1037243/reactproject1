const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    title: {
        type: String
    },

    pictureURL: {
        type: String
    },

    description: {
        type: String
    },

    address: {
        type: String
    }
});

const Location = mongoose.model("Location", userSchema);
module.exports = { Location };