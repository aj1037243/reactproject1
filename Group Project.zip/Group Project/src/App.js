import React from 'react';
import MainNavigation from './components/MainNavigation';
import Main from './components/Main';
import Home from './components/Home';
import About from './components/About';
import MoreInformation from './components/MoreInformation';
import Login from './components/Login';
import Footer from './components/Footer';
import { BrowserRouter, Routes, Route } from "react-router-dom";

const App = () => (
    <React.Fragment>
        <MainNavigation />
        <BrowserRouter>
            <Routes>
                <Route path='/' element={<Main />}>
                    <Route index element={<Home />} />
                </Route>
                <Route path="/about" element={<About />} />
                <Route path="/more_info" element={<MoreInformation />} />
                <Route path="/login" element={<Login />} />
            </Routes>
        </BrowserRouter>
        <Footer />
    </React.Fragment>
);

export default App;