import React from 'react';
import './css/NavLinks.css';

const NavLinks = props => (
    <ul className='nav-links'>
        <li>
            <a href="/">Home</a>
        </li>
        <li>
            <a href="/about">About</a>
        </li>
        <li>
            <a href="/more_info">Information</a>
        </li>
        <li>
            <a href="/login">Login</a>
        </li>
    </ul>
);

export default NavLinks;