import React from "react";

function AboutUs() {
  return (
    
    <div className=" contributors">

        <h3> Meet our Contributors</h3>
      <div className="sections">

        <div className="One">

            <div className="meet-one">
                <h3>Aaronweber Jodesty</h3>

                <p> Aaron is the Goat. End of Story</p>
            </div>

        </div>

        <div className="Two">

        <div className="meet-two">
            <h3>Spencer Skaggs</h3>

            <p> Spencer is the Goat. End of Story</p>
        </div>

        </div>

        </div>
    </div>

    

  )
}

export default AboutUs