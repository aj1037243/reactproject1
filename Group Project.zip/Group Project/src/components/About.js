import React from "react";
import './css/About.css';

const About = props => (
    <div className="about-page">
        <h1>Meet our Contributors</h1>
        <ul>
            <li>Aaronweber Jodesty</li>
            <li>Spencer Skaggs</li>
            <li>Jonas Lee</li>
        </ul>
    </div>
);

export default About;